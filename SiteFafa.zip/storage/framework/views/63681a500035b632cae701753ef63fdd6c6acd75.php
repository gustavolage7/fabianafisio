<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Laravel</title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet">

        <!-- Styles -->
        <style>
            body {
                background-image: url("img/BG Welcome.jpg");
				background-repeat: no-repeat, repeat;
				background-size: 100% 100%;
				background-position: center;
                color: #636b6f;
                font-family: 'Nunito', sans-serif;
                font-weight: 200;
                height: 100vh;
                margin: 0;
            }
			
			label{
				font-weight: bold;
			}
			
			#conteudo{
				margin-left: 2%;
			}
			
			#titulo{
				font-weight: bold;
				font-size: 60px;
				font-align: center;
				margin-left: 15%;
			}

            //botões
			
			@import  url('https://fonts.googleapis.com/css?family=Lato:100&display=swap');

			.container {
			  width: 400px;
			  height: 400px;
			  position: absolute;
			  left: 50%;
			  top: 50%;
			  transform: translate(-50%, -50%);
			  display: flex;
			  justify-content: center;
			  align-items: center;
			}

			.center {
			  width: 180px;
			  height: 60px;
			  position: absolute;
			}

			.btn {
			  width: 180px;
			  height: 60px;
			  cursor: pointer;
			  background: transparent;
			  border: 1px solid #91C9FF;
			  outline: none;
			  transition: 1s ease-in-out;
			  background-color: #FFC0CB;
			  color: #C71585;
			}

			svg {
			  position: absolute;
			  left: 0;
			  top: 0;
			  fill: none;
			  stroke: #fff;
			  stroke-dasharray: 150 480;
			  stroke-dashoffset: 150;
			  transition: 1s ease-in-out;
			}

			.btn:hover {
			  transition: 1s ease-in-out;
			  background: #C71585;
			  color: #ffffff;
			}

			.btn:hover svg {
			  stroke-dashoffset: -480;
			}

			.btn span {
			  font-size: 18px;
			  font-weight: 100;
			}

        </style>
    </head>
    <body>
        
        <div>
            <div>

            <div>
				<div style="font-size: 100px;">
				&nbsp
				</div>
                <div id="titulo">
                    Bem-vind@!
                </div>

                <div id="conteudo">
                    <label><p>Meu nome é Fabiana, curso fisioterapia na Faculdades Ciências Médicas de Minas Gerais e
					 <br>sou revendedora Avon!</p>
                        <p>Por este site, você poderá realizar pedidos da Avon e ainda marcar algum tipo de serviço como
						  <br>por exemplo a massagem linfática e a massagem redutora.</p>
						
                        Para saber mais, faça seu registro e acesse! Assim poderá ver a lista completa de serviços 
						e produtos.<label>
                </div><br>
                    <?php if(auth()->guard()->check()): ?>
                        <a href="<?php echo e(url('/home')); ?>"></a>
                    <?php else: ?>
						<div class="container">
							<div class="center" style="margin-left: 13%;">
								<a href="<?php echo e(route('login')); ?>">
									<button class="btn">
										<svg width="180px" height="60px" viewBox="0 0 180 60" class="border">
											<polyline points="179,1 179,59 1,59 1,1 179,1" class="bg-line" />
											<polyline points="179,1 179,59 1,59 1,1 179,1" class="hl-line" />
										</svg>
										<span>Login</span>
									</button>
								</a>
							</div>
						</div>

                    <?php if(Route::has('register')): ?>
                        <div class="container">
							<div class="center" style="margin-left: 28%;">
								<a href="<?php echo e(route('register')); ?>">
									<button class="btn">
										<svg width="180px" height="60px" viewBox="0 0 180 60" class="border">
										  <polyline points="179,1 179,59 1,59 1,1 179,1" class="bg-line" />
										  <polyline points="179,1 179,59 1,59 1,1 179,1" class="hl-line" />
										</svg>
										<span>Registrar</span>
									</button>
								</a>
							</div>
						</div>
                    <?php endif; ?>
                <?php endif; ?>
            </div>
        </div>
        </div>
		<div style="margin-top: 5%;">
			<div style="float: left; margin-top: 8%;">
				<a href="https://br.freepik.com/fotos/fundo">Fundo foto criado por valeria_aksakova - br.freepik.com</a>
			</div>
			<div style="float: right; width: 100px; height: 50px; margin-right: 10%;">
				<img src="img/Selo Avon.png" style="width:200px; height: 100px;">
			</div>
		</div>
    </body>
</html>
<?php /**PATH C:\xampp\htdocs\painel_revenda\resources\views/welcome.blade.php ENDPATH**/ ?>