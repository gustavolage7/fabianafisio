<?php $__env->startSection('content'); ?>

<style>


        #conteudo{
            background-color: #FFC0CB;
            float: right;
            width: 75%;
            height: 95vh;
            overflow:auto; 
            
        }

        #par{
            background-color: #B0C4DE;
        }

        #impar{
            background-color: #ffecef;
        }

        #banido{
            background-color: darkred;
            color: white;
        }

        #icon{
            width: 20px;
            height: 20px;
        }

        #btn_create{
            float: left;
            margin-left: 5%;
            margin-top: 2%;
            margin-bottom: 2%;
        }

        #lupa{
            width: 30px;
            height: 30px;
            align: left;
            margin-right: 10%;
        }

        #tittle_newmensage{
            font-size: 20px;
            font-weight: bolder;
        }

        #msg{
            width: 90%;
            height: 10vh;
        }

        #div_left{
            width: 50%;
            float:left;
        }

        #div_right{
            width: 50%;
            float: right;
        }
        
        h1{
            text-align: center;
            text-decoration-line: underline;
            font-weight: bold;
        }
    
        h2{
            text-align: center;
        }
    
        img{
            float: right;
            margin-right: 2%;
            width: 400px;
        }

        table{
            width: 90%;
            text-align: center;
            margin-left: 5%;
            margin-top: 13%;

        }

        th{
            background-color: #C71585;
            color: white;
        }

        button{
            background-color: #FFC0CB;
            width: 100px;
            height: 40px;
        }

        button:hover{
            background-color: #C71585;
            color: white;
        }

        form{
            margin-left: 5%;
        }

</style>

<div class="container" >
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">

                <div class="card-body" id='mae'>
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                    
                    <div id='conteudo'>
                            <h1><?php echo e($contatos->titulo); ?></h1>

                            <div id="div_left">
                            <form method="POST" action="/contatos/inserirResposta">
                                <?php echo csrf_field(); ?>
        
                                <div class="form-group row">
                                    
                                <label id="tittle_newmensage">Nova mensagem</label><br>
                                        
                                <div class="form-group row">

                                    <input hidden id="titulo" name="titulo" value="<?php echo e($contatos->titulo); ?>">
                                    <input hidden id="user_id" name="user_id" value="<?php echo e(auth()->user()->id); ?>">
                                    <input hidden id="cod_contato" name="cod_contato" value="<?php echo e($contatos->cod_contato); ?>">
                                    <input hidden id="id_original" name="id_original" value="<?php echo e($id_original); ?>">

                                    
                                    <div class="col-md-6">
                                        <label>Mensagem: </label><br>
                                        <textarea placeholder="Mensagem (Máx 5000 caracteres)" id="msg" type="textarea" name="msg" required autocomplete="msg"></textarea>
        
                                    </div>
                                </div>
                                <input id="id_user" name="id_user" value="<?php echo e(auth()->user()->id); ?>" hidden>
                                
                                    <button type="submit">
                                                Enviar
                                    </button>
                                    
                            </form>
                            </div>
                            </div>
                            <div id="div_right">
                                <label id="tittle_newmensage">Dados do solicitante</label><br>
                                <?php $__currentLoopData = $usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $autor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($contatos->user_id == $autor->id): ?>
                                <br><label>Nome:    </label>    <?php echo e($autor->name); ?>

                                <br><br><label>E-mail:  </label><?php echo e($autor->email); ?>

                                <br><br><label>Telefone:</label><?php echo e($autor->telefone); ?>

                                <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <br>&nbsp
                            </div>
                            <br><br>
                            

                            <table>

                                <tr>
                                    <th style="width: 5%">
                                        #
                                    </th>
                                    <th style="width: 35%">
                                        Mensagem
                                    </th>
                                    <th style="width: 15%">
                                        Responsável envio
                                    </th>
                                    <th style="width: 15%">
                                        Postado em
                                    </th>
                                    <th style="width: 15%">
                                        Última Atualização
                                    </th>
                                </tr>

                                <?php
                                    $linha = 1;
                                ?>

                                <?php $__currentLoopData = $mensagens; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mensagem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                if($linha%2==0){
                                echo "<tr id='par'>";
                                }else{
                                echo "<tr id='impar'>";
                                }
                                ?>
                                    <td>
                                        <?php echo e($linha); ?>

                                    </td>
                                    <td>
                                        <?php echo e($mensagem->mensagem); ?>

                                    </td>
                                    <td>
                                        <?php $__currentLoopData = $usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usuario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($mensagem->user_id == $usuario->id): ?>
                                            <?php echo e($usuario->name); ?>

                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </td>
                                    <td>
                                        <?php echo e(date('d/m/Y H:m:s', strtotime($mensagem->created_at))); ?>

                                    </td>
                                    <td>
                                        <?php echo e(date('d/m/Y H:m:s', strtotime($mensagem->updated_at))); ?>

                                    </td>
                                </tr>
                                <?php
                                  $linha ++;  
                                ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </table>
                            
                            <a href="/contatos" id="btn_create">
                                <button type="button">
                                    Voltar
                                </button>
                            </a>
                            
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\painel_revenda\resources\views/visualizarContatos.blade.php ENDPATH**/ ?>