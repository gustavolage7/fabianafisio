<?php $__env->startSection('content'); ?>

<style>

    #conteudo{
        background-color: #FFC0CB;
        float: right;
        width: 75%;
        height: 100vh;
    }

    h1{
        text-align: center;
        text-decoration-line: underline;
        font-weight: bold;
    }

    h2{
        text-align: center;
    }

    img{
        float: right;
        margin-right: 2%;
        width: 400px;
    }
    
</style>

<?php
    $logado = Auth::user()->name;
?>

<div id="conteudo">

    <h1>Nossas boas vindas para <?php echo e($logado); ?></h1>
    
    <h2>Quem sou</h2>

    <img src="img/foto.jpeg">

    <h4>Estudo</h4>

    <label>Cursando o 5° ano de Fisioterapia na Faculdades de Ciências Médicas de Minas Gerais (FCMMG)</label>

    <h4>Cursos Extras</h4>

    <label>Teste</label>

    <h4>Um pouco sobre...</h4>

    <label>Teste</label>


</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\painel_revenda\resources\views/home.blade.php ENDPATH**/ ?>