<?php $__env->startSection('content'); ?>

<style>


        #conteudo{
            background-color: #FFC0CB;
            float: right;
            width: 75%;
            height: 100vh;
        }

        #lateral{
            width: 25%;
            height: 100vh;
            float: left;
        }

        #colA{
            width: 40%;
        }

        #colB{
            width: 60%;
        }

        #TR_Impar{
            background-color: #B0C4DE;
        }

        #TR_Par{
            background-color: #ffecef;
        }
    
        h1{
            text-align: center;
            text-decoration-line: underline;
            font-weight: bold;
            margin-top: 5%;
        }
    
        h2{
            text-align: center;
        }
    
        img{
            float: right;
            margin-right: 2%;
            width: 400px;
        }

        label{
            font-weight: bold;
            font-size: 20px;
            margin-right: 5%;
        }

        table{
            width: 50%;
        }

        button{
            background-color: #FFC0CB;
            width: 100px;
            height: 40px;
            margin-left: 3%;
            margin-top: 3%;
        }

        button:hover{
            background-color: #C71585;
            color: white;
        }

</style>

<div class="container" >
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">

                <div class="card-body" id='mae'>
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    
                    <div id='conteudo'>
                        <h1>Perfil</h1>
                        <div id="lateral">
                            
                        </div>
                        <?php $id = $user->id ?>
                        <form method="POST" action="/usuarios/editProfile/<?php echo e($id); ?>">
                            <?php echo csrf_field(); ?>
    
                            <div class="form-group row">
                                
                                <div class="col-md-6">
                                    <label>Nome: </label>
                                    <input value="<?php echo e($user->name); ?>" minlength="10" maxlength="100" onkeypress="return onlyletter();" placeholder="Nome" id="name" type="text" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="name" required autocomplete="name" autofocus>
    
                                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <br>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <br>
                            <div class="form-group row">
                                
                                <div class="col-md-6">
                                    <label>E-mail: </label>
                                    <input value="<?php echo e($user->email); ?>" placeholder="E-mail" id="email" type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email" required autocomplete="email">
    
                                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <br>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <br>
                            <div class="form-group row">
                                
                                <div class="col-md-6">
                                    <label>Usuário: </label>
                                    <input value="<?php echo e($user->usuario); ?>" placeholder="Usuário (Min. 3 caract / Máx. 20 caract" id="usuario" type="text" class="form-control <?php $__errorArgs = ['usuario'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="usuario" required autocomplete="usuario" autofocus>
    
                                    <?php $__errorArgs = ['usuario'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <br>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <br>
                            <div class="form-group row">
                                
                                <div class="col-md-6">
                                    <label>Telefone: </label>
                                    <input value="<?php echo e($user->telefone); ?>" onkeypress="return onlynumber();" placeholder="Telefone, Ex: DDDXXXXXXXXX" id="telefone" type="text" class="form-control <?php $__errorArgs = ['telefone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="telefone" required autocomplete="telefone" autofocus>
    
                                    <?php $__errorArgs = ['telefone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <br>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <br>
                                <div class="form-group row">
                                        
                                    <div class="col-md-6">
                                        <label>CPF: </label>
                                        <input value="<?php echo e($user->cpf); ?>" onkeypress="return onlynumber();" placeholder="CPF: XXXXXXXXXXX" minlength="11" maxlength="14" id="cpf" type="text" class="form-control <?php $__errorArgs = ['cpf'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="cpf" required autocomplete="cpf" autofocus>
        
                                        <?php $__errorArgs = ['cpf'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <br>
                                            <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                            </div>
                            <br>
                            <div class="form-group row">
                                
                                <div class="col-md-6">
                                    <label>Data de Nascimento: </label>
                                    <input value="<?php echo e($user->nascimento); ?>" placeholder="Data de nascimento: dd/mm/aaaa" id="nascimento" type="date" class="form-control <?php $__errorArgs = ['nascimento'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="nascimento" required autocomplete="nascimento" autofocus>
    
                                    <?php $__errorArgs = ['nascimento'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <br>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                        </div>
                        <br>
                            <div class="form-group row">
                                
                                <div class="col-md-6">
                                    <label>Senha: </label>
                                    <input minlength="8" maxlength="20" id="password" type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password" autocomplete="new-password">
    
                                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <br>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <br>
                            
                                <button type="submit">
                                            Salvar
                                </button>
                                <a href="/usuarios/perfil">
                                <button type="button">
                                    Voltar
                                </button>
                                </a>
                        </form>
                        
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\painel_revenda\resources\views/editarPerfil.blade.php ENDPATH**/ ?>