<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/





    Route::get('/', function () {
        return view('welcome');
    });
    
    Auth::routes();
        
    Route::get('/home', 'HomeController@index', function(){
        return view('home');
    });

    Route::prefix('/usuarios')->group(function(){

        Route::post('/registroUsuario', 'UsuariosController@create');

        Route::get('/lista', 'UsuariosController@index')->middleware('auth');

        Route::get('/perfil', 'UsuariosController@show')->middleware('auth');
        
        Route::get('/edit/{id}', 'UsuariosController@edit')->middleware('auth');

        Route::post('/editar/{id}', 'UsuariosController@update')->middleware('auth');

        Route::get('/editarPerfil/{id}', 'UsuariosController@editProfile')->middleware('auth');
        
        Route::post('/editProfile/{id}', 'UsuariosController@profileUpdate')->middleware('auth');


    });

    Route::prefix('/portifolio')->group(function(){
    
        Route::get('/', 'HomeController@index', function(){
            return view('portifolio');
        });

        Route::get('/editar', 'HomeController@index', function(){
            echo 'Edição da arte postada';
        });

    });

    Route::prefix('/exposicao')->group(function(){
    
        Route::get('/', 'HomeController@index', function(){
            return view('exposicao');
        });

        Route::get('/visualizacao', 'HomeController@index', function(){
            echo 'Dados da postagem clicada';
        });

    });

    Route::prefix('/vendas')->group(function(){
    
        Route::get('/lista', 'VendasController@index', function(){
            echo 'Dados da postagem clicada';
        });

    });

    Route::prefix('/contatos')->group(function(){

        Route::get('/', 'ContatoController@index')->middleware('auth');
        
        Route::get('/cadastrarContatos', 'ContatoController@create')->middleware('auth');

        Route::post('/criarContato', 'ContatoController@store')->middleware('auth');

        Route::get('/visualizarContatos/{id}', 'ContatoController@show')->middleware('auth');
        
        Route::post('/inserirResposta', 'ContatoController@update')->middleware('auth');

    });


    Route::prefix('/agendas')->group(function(){
        Route::get('/lista', 'AgendaController@index')->middleware('auth');

    });