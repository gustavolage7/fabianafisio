<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Faby Nephelle - Saúde e Beleza</title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet">

        <!-- Styles -->
        <style>
            body {
                background-image: url("../img/BG Cadastro.jpg");
				background-repeat: no-repeat, repeat;
				background-size: 100% 100%;
				background-position: center;
                color: #636b6f;
                font-family: 'Nunito', sans-serif;
                font-weight: 200;
				height: 650px;
                margin: 0;
            }
			
			input{
				height: 20px;
				width: 80%;
				font-size: 15px;
			}

            button{
                background-color: #FFC0CB;
                width: 100px;
                height: 40px;
            }

            button:hover{
                background-color: #C71585;
                color: white;
            }
			
			#mae{
				background-image: url("../img/fundoform.png");
				width: 30%;
				height: 80%;
				margin: auto;
				margin-top: 5%;
			}
			
			
			
			#h1{
				font-size: 30px;
				font-weight: bold;
				text-align: center;
				margin-bottom: 2%;
			}
			
			#campos{
				text-align: center;
			}

            

        </style>
    </head>
    <body>
        
        <div class="container" id="mae">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header" id="h1">Novo registro</div>

                <div class="card-body" id="campos">
                    <form method="POST" action="/usuarios/registroUsuario">
                        @csrf

                        <div class="form-group row">
                            
                            <div class="col-md-6">
                                <input value="{{$formRegistro['name']}}" minlength="10" maxlength="100" onkeypress="return onlyletter();" placeholder="Nome" id="name" type="text" class="form-control @error('name') is-invalid @enderror" name="name" required autocomplete="name" autofocus>

                                @error('name')
                                <br>
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
                            </div>
                        </div>
                        <br>
                        <div class="form-group row">
                            
                            <div class="col-md-6">
                                @if($erro_email != "E-mail já cadastrado")
                                <input value="{{$formRegistro['email']}}" placeholder="E-mail" id="email" type="email" class="form-control @error('email') is-invalid @enderror" name="email" required autocomplete="email">
                                @else
                                <input placeholder="{{$erro_email}}" id="email" type="email" class="form-control @error('email') is-invalid @enderror" name="email" required autocomplete="email">
                                @endif

                                @error('email')
                                <br>
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
                            </div>
                        </div>
                        <br>
                        <div class="form-group row">
                            
                            <div class="col-md-6">
                                <input value="{{$formRegistro['usuario']}}" placeholder="Usuário (Min. 3 caract / Máx. 20 caract" id="usuario" type="text" class="form-control @error('usuario') is-invalid @enderror" name="usuario" required autocomplete="usuario" autofocus>

                                @error('usuario')
                                <br>
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
                            </div>
                        </div>
                        <br>
                        <div class="form-group row">
                            
                            <div class="col-md-6">
                                <input value="{{$formRegistro['telefone']}}" onkeypress="return onlynumber();" placeholder="Telefone, Ex: DDDXXXXXXXXX" id="telefone" type="text" class="form-control @error('telefone') is-invalid @enderror" name="telefone" required autocomplete="telefone" autofocus>

                                @error('telefone')
                                <br>
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
                            </div>
                            <br>
                            <div class="form-group row">
                                    
                                <div class="col-md-6">
                                    @if($erro_cpf != "CPF já cadastrado")
                                    <input value="{{$formRegistro['cpf']}}" onkeypress="return onlynumber();" placeholder="CPF: XXXXXXXXXXX" minlength="11" maxlength="14" id="cpf" type="text" class="form-control @error('cpf') is-invalid @enderror" name="cpf" required autocomplete="cpf" autofocus>
                                    @else
                                    <input placeholder="{{$erro_cpf}}" onkeypress="return onlynumber();" minlength="11" maxlength="14" id="cpf" type="text" class="form-control @error('cpf') is-invalid @enderror" name="cpf" required autocomplete="cpf" autofocus>
                                    @endif
    
                                    @error('cpf')
                                    <br>
                                        <span class="invalid-feedback" role="alert">
                                            <strong>{{ $message }}</strong>
                                        </span>
                                    @enderror
                                </div>
                        </div>
                        <br>
                        <div class="form-group row">
                            
                            <div class="col-md-6">
                                <input value="{{$formRegistro['nascimento']}}" placeholder="Data de nascimento: dd/mm/aaaa" id="nascimento" type="date" class="form-control @error('nascimento') is-invalid @enderror" name="nascimento" required autocomplete="nascimento" autofocus>

                                @error('nascimento')
                                <br>
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
                            </div>
                    </div>
                    <br>
                        <div class="form-group row">
                            
                            <div class="col-md-6">
                                <input value="{{$formRegistro['password']}}" placeholder="Senha: (Min. 8 caract. / Máx. 20 caract)" minlength="8" maxlength="20" id="password" type="password" class="form-control @error('password') is-invalid @enderror" name="password" required autocomplete="new-password">

                                @error('password')
                                <br>
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
                            </div>
                        </div>
                        <br>
                        <div class="form-group row">
                            
                            <div class="col-md-6">
                                <input value="{{$formRegistro['password_confirmation']}}" placeholder="Confirme sua senha" id="password-confirm" type="password" class="form-control" name="password_confirmation" required autocomplete="new-password">
                            </div>
                        </div>
                        <br>
                        	<button type="submit">
										Registrar
                            </button>
                            <a href="/">
                            <button type="button">
                                Voltar
                            </button>
                            </a>
					</form>
                </div>
            </div>
        </div>
    </div>
</div>
		
		<script>
    function onlynumber(evt) {
        var theEvent = evt || window.event;
        var key = theEvent.keyCode || theEvent.which;
        key = String.fromCharCode( key );
        //var regex = /^[0-9.,]+$/;
        var regex = /^[0-9.]+$/;
        if( !regex.test(key) ) {
           theEvent.returnValue = false;
           if(theEvent.preventDefault) theEvent.preventDefault();
        }
     }

     function onlyletter(evt) {
        var theEvent = evt || window.event;
        var key = theEvent.keyCode || theEvent.which;
        key = String.fromCharCode( key );
        //var regex = /^[0-9.,]+$/;
        var regex = /[A-Za-záàâãéèêíïóôõöúçñÁÀÂÃÉÈÍÏÓÔÕÖÚÇÑ ]+$/;
        if( !regex.test(key) ) {
           theEvent.returnValue = false;
           if(theEvent.preventDefault) theEvent.preventDefault();
        }
     }

</script>
    </body>
</html>
