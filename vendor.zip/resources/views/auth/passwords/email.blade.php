@extends('layouts.app')

@section('content')
<style>
#h1{
    font-size: 30px;
    font-weight: bold;
    text-align: center;
    margin-bottom: 30px;
}

#campo{
    text-align: center;

}

#mae{
    background-color: #B0C4DE;
    height: 520px;

}

input{
    width: 300px;
    height: 25px;

}

button{
    width: auto;
    padding: 0 25px;
    height: 40px;
    color: #000;
    background-color: #B0C4DE;
    font-weight: 600;
    letter-spacing: .1rem;
    text-decoration: none;
    text-transform: uppercase;
}

button:hover{
    background-color: #000080;
    color: #fff;
    font-size: 15px;
}

</style>

<div class="container" id="mae">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <br>
                <div class="card-header" id="h1">{{ __('Recuperação de senha') }}</div>

                <div class="card-body" id="campo">
                    @if (session('status'))
                        <div class="alert alert-success" role="alert">
                            {{ session('status') }}
                        </div>
                    @endif

                    <form method="POST" action="{{ route('password.email') }}">
                        @csrf

                        <div class="form-group row">
                            
                            <div class="col-md-6">
                                <input placeholder="E-mail cadastrado" id="email" type="email" class="form-control @error('email') is-invalid @enderror" name="email" value="{{ old('email') }}" required autocomplete="email" autofocus>

                                @error('email')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
                            </div>
                        </div>
                        <br>
                        <div class="form-group row mb-0">
                            <div class="col-md-6 offset-md-4">
                                <button type="submit" class="btn btn-primary">
                                    {{ __('Enviar link de recuperação') }}
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
