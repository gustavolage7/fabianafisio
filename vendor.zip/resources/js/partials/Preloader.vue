<script type="text/ecmascript">

    export default {

    }
</script>

<template>
    <div class="flex flex-col items-center justify-center text-light">
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" class="spin fill-current w-10">
            <path d="M10 12a2 2 0 1 1 0-4 2 2 0 0 1 0 4zm0-6a2 2 0 1 1 0-4 2 2 0 0 1 0 4zm0 12a2 2 0 1 1 0-4 2 2 0 0 1 0 4z"/>
        </svg>
    </div>
</template>
