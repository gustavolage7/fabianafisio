<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <?php $pagina = ""; ?>
    <title>Faby Nephelle - Saúde e Beleza</title>

    <!-- Scripts -->
    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">

    <!-- Styles -->
    <style>

                @-webkit-keyframes fadeIn {
                0% { opacity: 0; }
                100% { opacity: 1; } 
                }
                @-moz-keyframes fadeIn {
                0% { opacity: 0;}
                100% { opacity: 1; }
                }
                @-o-keyframes fadeIn {
                0% { opacity: 0; }
                100% { opacity: 1; }
                }
                @keyframes  fadeIn {
                0% { opacity: 0; }
                100% { opacity: 1; }
                }

            .fadeIn{
                background-color: #B0C4DE;;
            
            }
            
            .fadeIn{
            
                -webkit-animation: fadeIn 1.5s ease-in-out;
                -moz-animation: fadeIn 1.5s ease-in-out;
                -o-animation: fadeIn 1.5s ease-in-out;
                animation: fadeIn 1.5s ease-in-out;
            
            }

            html{
                height: 100%;
            }

            a.animated-button.thar-three {
                color: #C71585;
                width: 95%;
                height: 30px;
                background-color: #FFC0CB;
                cursor: pointer;
                display: block;
                text-align: center;
                font-size: 20px;
                position: relative;
                border: 2px solid #C71585;
                transition: all 0.4s cubic-bezier(0.42, 0, 0.58, 1);
            0s;
            }
            a.animated-button.thar-three:hover {
                color: #fff !important;
                background-color: transparent;
                text-shadow: nthree;
            }
            a.animated-button.thar-three:hover:before {
                left: 0%;
                right: auto;
                width: 100%;
            }
            a.animated-button.thar-three:before {
                display: block;
                position: absolute;
                top: 0px;
                right: 0px;
                height: 100%;
                width: 0px;
                z-index: -1;
                content: '';
                color: #fff !important;
                background: #C71585;
                transition: all 0.4s cubic-bezier(0.42, 0, 0.58, 1);
            0s;
            }

            #logo{
                width: 100%;
                height: 100px;

            }

            #app{
                float: left;
                height: 100%;
                width: 25%;
            }

            #menu{
                margin-left: 2%;
            }


    </style>


</head>
<body class="fadeIn">
    <div id="app">
        <nav>
            <div>
                <div>
                <img src="../../img/ideiaLogo.png" alt="Banner" id="logo">
                </div>
                <div id='logado' aria-labelledby="navbarDropdown">
                    
                        <div id='divisor'>&nbsp</div>
                        Usuário logado: <?php echo e(Auth::user()->usuario); ?> <span></span>
                        &nbsp;
                        <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                                       onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                        <?php echo e(__('Logout')); ?>

                        </a>
                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                            <?php echo csrf_field(); ?>
                        </form>
                        
                        <br>
                        <br>
                
                 
    
                </div>
                <div id='menu'>
                    <?php if(Auth::user()->acesso=="Banido"): ?>
                    <label>Usuário banido!
                        <br><br>Foi identificado alguma irregularidade em sua conta, para regularizar o seu acesso,
                        <br>entre em contato com a administração:
                        <br> - contato@fabynephelle.com.br
                        <br> - Ou pela página Contato

                        <br><br><br>

                    </label>
                    <?php else: ?>
                    <div class="col-md-3 col-sm-3 col-xs-6"> <a href="/home" class="btn btn-sm animated-button thar-three">Página Inicial</a> </div>
                    <?php if(Auth::user()->acesso == "Administrador"): ?>
                    <div class="col-md-3 col-sm-3 col-xs-6"> <a href="/usuarios/lista" class="btn btn-sm animated-button thar-three">Usuários</a> </div>
                    <?php endif; ?>
                    <div class="col-md-3 col-sm-3 col-xs-6"> <a href="/usuarios/perfil" class="btn btn-sm animated-button thar-three">Minha Conta</a> </div>
                    <div class="col-md-3 col-sm-3 col-xs-6"> <a href="/agendas/lista" class="btn btn-sm animated-button thar-three">Agenda</a> </div>
                    <div class="col-md-3 col-sm-3 col-xs-6"> <a href="#" class="btn btn-sm animated-button thar-three">Serviços</a> </div>
                    <div class="col-md-3 col-sm-3 col-xs-6"> <a href="#" class="btn btn-sm animated-button thar-three">Revenda</a> </div>
                    <div class="col-md-3 col-sm-3 col-xs-6"> <a href="/vendas/lista" class="btn btn-sm animated-button thar-three">Venda</a> </div>
                    <?php endif; ?>
                    <div class="col-md-3 col-sm-3 col-xs-6"> <a href="/contatos" class="btn btn-sm animated-button thar-three">Contato</a> </div>

                </div>
            </div>

            </div>
        </nav>

        <main class="py-4">
            <?php echo $__env->yieldContent('content'); ?>
        </main>
    </div>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\painel_revenda\resources\views/layouts/app.blade.php ENDPATH**/ ?>