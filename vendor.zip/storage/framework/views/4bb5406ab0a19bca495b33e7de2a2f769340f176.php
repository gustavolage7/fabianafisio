<?php $__env->startSection('content'); ?>

<style>


        #mae{
            background-color: #B0C4DE;
            height: 550px;

        }

        #conteudo{
            margin-top: 60px;
            width: 50%;
            margin-left: 300px;
            font-weight: bold;
        }

</style>

<div class="container" >
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">

                <div class="card-body" id='mae'>
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                    
                    <div id='conteudo'>
                        Aqui no portifólio online, você pode fazer upload de seus trabalhos gráficos, sendo eles de diversas modalidades como pintura digital, fotografia, montagem, animação e entre outros.
                        <p>
                        Dentre seus trabalhos que você inserir em seu portifólio, lhe damos a liberdade de tornar aqueles que mais lhe agradem como públicos, assim todos os membros podem visualizar seus trabalhos.
                        <p>
                        Os trabalhos publicados não possuem direitos autorais. Porém, caso vá utilizar o trabalho de terceiros, pedimos que tenha o senso de dar os devidos créditos pelo trabalho ao artista desenvolvedor.
                        <p>
                        Deseja contatar o artista de um determinado trabalho para desenvolver um projeto para você? Fique a vontade para contatar aquele que possuir o perfil e estilo que lhe atenda para lhe fazer uma proposta.
                        <p>
                        IMPORTANTE: Artes que possuam material impróprio para menores de idade devem ser assinalados como tal, para que membros que sejam menores não possam ter acesso. Trabalhos deste estilo que não forem sinalizados, poderão ser excluídos, e em caso de reincidência, a conta pode ser banida.
                        <p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projetoPortifolio\resources\views/home.blade.php ENDPATH**/ ?>