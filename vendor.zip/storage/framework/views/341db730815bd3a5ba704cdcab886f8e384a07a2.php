<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Portifólio Online')); ?></title>

    <!-- Scripts -->
    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">

    <!-- Styles -->
    <style>

        body{
            background-color: #B0C4DE;

        }

        #menu{
            float: right;
            margin-top: 35px;
            text-align: left;
            width:90%;

        }

        button{
            width: auto;
            padding: 0 25px;
            height: 40px;
            color: #000;
            background-color: #B0C4DE;
            font-weight: 600;
            letter-spacing: .1rem;
            text-decoration: none;
            text-transform: uppercase;
        }

        button:hover{
            background-color: #000080;
            color: #fff;
            font-size: 15px;
        }

        #logado{
            float: right;
            width: 100%;
            text-align: left;
            background-color: #B0C4DE;

        }

        #divisor{
            background-color: #000;
            height: 5px;

        }


    </style>


</head>
<body>
    <div id="app">
        <nav class="navbar navbar-expand-md navbar-light bg-white shadow-sm">
            <div class="container">
                <?php if(Auth::guest()): ?>
                <a href="<?php echo e(url('/')); ?>"><img src="img\banner.jpg" alt="Banner" width=100% height=200></a>
                <?php endif; ?>
                <?php if(Auth::check()): ?>
                <a href="<?php echo e(url('/home')); ?>"><img src="img\logotemp.jpg" alt="Banner" width=100px height=100px></a>
                <div id='menu'>
                 
                    <a href="<?php echo e(url('/home')); ?>"><button>HOME</button></a>
                    <a href="<?php echo e(url('/perfil')); ?>"><button>PERFIL</button></a>
                    <a href="<?php echo e(url('/portifolio')); ?>"><button>PORTIFÓLIO</button></a>
                    <a href="<?php echo e(url('/exposicao')); ?>"><button>EXPOSIÇÃO</button></a>
                    <?php if(Auth::user()->acesso==1): ?>
                    <a href="<?php echo e(url('/usuarios')); ?>"><button>USUÁRIOS</button></a>
                    <?php else: ?>
                    &nbsp
                <?php endif; ?>
                </div>
                <?php endif; ?>
            </div>

                <div id='logado' class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                    <?php if(Auth::guest()): ?>
                        <a class="nav-link" href="<?php echo e(url('/')); ?>"><?php echo e(__('Voltar')); ?></a>
                    <?php endif; ?>
                    <?php if(Auth::check()): ?>
                        <div id='divisor'>&nbsp</div>
                        Usuário logado: <?php echo e(Auth::user()->usuario); ?> <span class="caret"></span>
                        &nbsp;
                        <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                                       onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                        <?php echo e(__('Logout')); ?>

                        </a>
                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                            <?php echo csrf_field(); ?>
                        </form>


                    <?php endif; ?>

                </div>
            </div>
        </nav>

        <main class="py-4">
            <?php echo $__env->yieldContent('content'); ?>
        </main>
    </div>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\projetoPortifolio\resources\views/layouts/app.blade.php ENDPATH**/ ?>