<?php $__env->startSection('content'); ?>

<style>


        #conteudo{
            background-color: #FFC0CB;
            float: right;
            width: 75%;
            height: 100vh;
            
        }

        #par{
            background-color: #B0C4DE;
        }

        #impar{
            background-color: #ffecef;
        }

        #banido{
            background-color: darkred;
            color: white;
        }

        #icon{
            width: 20px;
            height: 20px;
            align: left;
            margin-right: 30%;
        }
        
        h1{
            text-align: center;
            text-decoration-line: underline;
            font-weight: bold;
        }
    
        h2{
            text-align: center;
        }
    
        img{
            float: right;
            margin-right: 2%;
            width: 400px;
        }

        table{
            width: 90%;
            text-align: center;
            margin-left: 5%;

        }

        th{
            background-color: #C71585;
            color: white;
        }

</style>

<?php if(auth()->user()->acesso != "Administrador"): ?>
    <script>window.location.href = "/home";</script>
<?php endif; ?>

<div class="container" >
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">

                <div class="card-body" id='mae'>
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                    
                    <div id='conteudo'>
                            <h1>Lista de Usuários</h1>

                            <table>

                                <tr>
                                    <th>
                                        ID
                                    </th>
                                    <th>
                                        Nome
                                    </th>
                                    <th>
                                        E-mail
                                    </th>
                                    <th>
                                        Acesso
                                    </th>
                                    <th>
                                        Ações
                                    </th>
                                </tr>

                                <?php
                                    $linha = 1;
                                ?>

                                <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usuario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                if($usuario->acesso == "Banido"){
                                echo "<tr id='banido'>";
                                }else if($linha%2==0 && $usuario->acesso != "Banido"){
                                echo "<tr id='par'>";
                                }else if($linha%2!=0 && $usuario->acesso != "Banido"){
                                echo "<tr id='impar'>";
                                }
                                ?>
                                    <td>
                                        <?php echo e($usuario->id); ?>

                                    </td>
                                    <td>
                                        <?php echo e($usuario->name); ?>

                                    </td>
                                    <td>
                                        <?php echo e($usuario->email); ?>

                                    </td>
                                    <td>
                                        <?php if($usuario->acesso == "Usuario"): ?>
                                        Usuário
                                        <?php else: ?>
                                        <?php echo e($usuario->acesso); ?>

                                        <?php endif; ?>
                                    </td>
                                    <?php if(Auth::user()->id == $usuario->id || Auth::user()->acesso == "Administrador"): ?>
                                    <td id="acao">
                                        <?php $id = $usuario->id ?>
                                        <a href="/usuarios/edit/<?php echo e($id); ?>"><img src="../../img/edit.png" id="icon"></a>
                                    </td>
                                    <?php else: ?>
                                    <td id="acao">
                                        <a onclick="negado()"><img src="../../img/negado.png" id="icon"></a>
                                    </td>
                                    <?php endif; ?>
                                </tr>
                                <?php
                                  $linha ++;  
                                ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </table>
                        
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>

    function negado(){
        alert("Acesso negado!\nVocê não possui permissão para tal operação!");
    }

</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\painel_revenda\resources\views/usuarios.blade.php ENDPATH**/ ?>