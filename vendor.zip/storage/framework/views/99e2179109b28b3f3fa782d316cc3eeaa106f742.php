<?php $__env->startSection('content'); ?>

<style>


        #conteudo{
            background-color: #FFC0CB;
            float: right;
            width: 75%;
            height: 100vh;
            
        }

        #par{
            background-color: #B0C4DE;
        }

        #impar{
            background-color: #ffecef;
        }

        #banido{
            background-color: darkred;
            color: white;
        }

        #icon{
            width: 20px;
            height: 20px;
            align: left;
            margin-right: 30%;
        }
        
        h1{
            text-align: center;
            text-decoration-line: underline;
            font-weight: bold;
        }
    
        h2{
            text-align: center;
        }
    
        img{
            float: right;
            margin-right: 2%;
            width: 400px;
        }

        table{
            width: 90%;
            text-align: center;
            margin-left: 5%;

        }

        th{
            background-color: #C71585;
            color: white;
        }

</style>

<?php if(auth()->user()->acesso != "Administrador"): ?>
    <script>window.location.href = "/home";</script>
<?php endif; ?>

<div class="container" >
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">

                <div class="card-body" id='mae'>
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                    
                    <div id='conteudo'>
                            <h1>Lista de Horários</h1>

                            <table>

                                <tr>
                                    <th>
                                        Dia
                                    </th>
                                    <th>
                                        Hora
                                    </th>
                                    <th>
                                        Cliente
                                    </th>
                                    <th>
                                        Serviço
                                    </th>
                                    <th>
                                        Ações
                                    </th>
                                </tr>

                                <?php
                                    $linha = 1;
                                ?>

                                
                            </table>
                        
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>

    function negado(){
        alert("Acesso negado!\nVocê não possui permissão para tal operação!");
    }

</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\painel_revenda\resources\views/agendas.blade.php ENDPATH**/ ?>