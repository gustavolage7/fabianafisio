<?php $__env->startSection('content'); ?>

<style>


        #mae{
            background-color: #B0C4DE;
            height: 550px;

        }

        #conteudo{
            margin-top: 60px;
            width: 50%;
            margin-left: 25%;
            font-weight: bold;
            text-align: center;
        }

</style>

<div class="container" >
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">

                <div class="card-body" id='mae'>
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                    
                    <div id='conteudo'>
                        <h1>Perfil</h1>

                        Nome: <?php echo e(Auth::user()->name); ?><br>
                        E-mail: <?php echo e(Auth::user()->email); ?><br>
                        Usuário: <?php echo e(Auth::user()->usuario); ?><br>
                        Telefone: <?php echo e(Auth::user()->telefone); ?><br>
                        CPF: <?php echo e(Auth::user()->cpf); ?><br>
                        Acesso:
                        <?php if(Auth::user()->acesso==1): ?>
                        Administrador
                        <?php endif; ?>
                        <?php if(Auth::user()->acesso==0): ?>
                        Usuário
                        <?php endif; ?>
                        <br>
                        Data de Nascimento: <?php echo e(Auth::user()->nascimento); ?><br>
                        
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projetoPortifolio\resources\views/perfil.blade.php ENDPATH**/ ?>