<?php $__env->startSection('content'); ?>

<style>


        #mae{
            background-color: #B0C4DE;
            height: 550px;

        }

        #conteudo{
            margin-top: 60px;
            width: 50%;
            margin-left: 300px;
            font-weight: bold;
        }

</style>

<div class="container" >
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">

                <div class="card-body" id='mae'>
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                    
                    <div id='conteudo'>
                            Usuários: <br>
                            <?php echo e(Auth::user()->usuario); ?>

                            <?php echo e(Auth::user()->id); ?>


                        
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projetoPortifolio\resources\views/usuarios.blade.php ENDPATH**/ ?>