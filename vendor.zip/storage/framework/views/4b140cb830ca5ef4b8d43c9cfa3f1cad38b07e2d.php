<?php $__env->startSection('content'); ?>

<style>


        #conteudo{
            background-color: #FFC0CB;
            float: right;
            width: 75%;
            height: 100vh;
            
        }

        #par{
            background-color: #B0C4DE;
        }

        #impar{
            background-color: #ffecef;
        }

        #banido{
            background-color: darkred;
            color: white;
        }

        #icon{
            width: 20px;
            height: 20px;
        }

        #btn_create{
            float: right;
            margin-right: 5%;
            margin-top: 5%;
        }

        #lupa{
            width: 30px;
            height: 30px;
            align: left;
            margin-right: 10%;
        }
        
        h1{
            text-align: center;
            text-decoration-line: underline;
            font-weight: bold;
        }
    
        h2{
            text-align: center;
        }
    
        img{
            float: right;
            margin-right: 2%;
            width: 400px;
        }

        table{
            width: 90%;
            text-align: center;
            margin-left: 5%;

        }

        th{
            background-color: #C71585;
            color: white;
        }

        button{
            background-color: #FFC0CB;
            width: 100px;
            height: 40px;
        }

        button:hover{
            background-color: #C71585;
            color: white;
        }

</style>

<div class="container" >
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">

                <div class="card-body" id='mae'>
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                    
                    <div id='conteudo'>
                            <h1>Lista de Contatos</h1>

                            <table>

                                <tr>
                                    <th style="width: 5%">
                                        #
                                    </th>
                                    <th style="width: 35%">
                                        Titulo
                                    </th>
                                    <th style="width: 15%">
                                        Data de Criação
                                    </th>
                                    <th style="width: 15%">
                                        Última Atualização
                                    </th>
                                    <th style="width: 15%">
                                        Status
                                    </th>
                                    <th style="width: 10%">
                                        Ações
                                    </th>
                                </tr>

                                <?php
                                    $linha = 1;
                                ?>

                                <?php $__currentLoopData = $contatos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contato): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                if($linha%2==0){
                                echo "<tr id='par'>";
                                }else{
                                echo "<tr id='impar'>";
                                }
                                ?>
                                    <td>
                                        <?php echo e($linha); ?>

                                    </td>
                                    <td>
                                        <?php echo e($contato->titulo); ?>

                                    </td>
                                    <td>
                                        <?php echo e(date('d/m/Y H:m:s', strtotime($contato->created_at))); ?>

                                    </td>
                                    <td>
                                        <?php echo e(date('d/m/Y H:m:s', strtotime($contato->updated_at))); ?>

                                    </td>
                                    <td>
                                        <?php echo e($contato->status); ?>

                                    </td>
                                    <td id="acao">
                                        
                                        
                                            <?php $id = $contato->id ?>
                                            <a href="/contatos/visualizarContatos/<?php echo e($id); ?>"><img src="../../img/lupa.png" id="icon"></a>
                                        
                                        
                                        
                                    </td>
                                </tr>
                                <?php
                                  $linha ++;  
                                ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </table>
                            
                            <a href="/contatos/cadastrarContatos" id="btn_create">
                                <button type="button">
                                    Novo contato
                                </button>
                            </a>
                        
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\painel_revenda\resources\views//contatos.blade.php ENDPATH**/ ?>