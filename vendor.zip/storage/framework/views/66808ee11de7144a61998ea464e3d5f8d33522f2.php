<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Laravel</title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet">

        <!-- Styles -->
        <style>
            html, body {
                background-color: #B0C4DE;
                color: #636b6f;
                font-family: 'Nunito', sans-serif;
                font-weight: 200;
                height: 100vh;
                margin: 0;
            }

            .full-height {
                height: 100vh;
            }

            .flex-center {
                align-items: center;
                display: flex;
                justify-content: center;
            }

            .position-ref {
                position: relative;
            }

            .top-right {
                position: absolute;
                right: 10px;
                top: 18px;
            }

            .content {
                text-align: center;
            }

            .title {
                font-size: 84px;
                color: #000;
            }

            .links > a {
                color: #000;
                padding: 0 25px;
                font-size: 13px;
                font-weight: 600;
                letter-spacing: .1rem;
                text-decoration: none;
                text-transform: uppercase;
            }

            .links > a:hover{
                background-color: #000080;
                color: #fff;
                font-size: 20px;

            }

            .m-b-md {
                margin-bottom: 30px;
            }

            label{
                font-weight: bold;
                color: #000000

            }

            button{
                width: auto;
                padding: 0 25px;
                height: 40px;
                color: #000;
                background-color: #B0C4DE;
                font-weight: 600;
                letter-spacing: .1rem;
                text-decoration: none;
                text-transform: uppercase;
            }

            button:hover{
                background-color: #000080;
                color: #fff;
                font-size: 15px;
            }

        </style>
    </head>
    <body>
        
        <div class="flex-center position-ref full-height">
            <div><img src="img\banner.jpg" alt="ban.jpg" width=100% height=200>

            <div class="content">
                <div class="title m-b-md">
                    Bem-vind@!
                </div>

                <div class="description">
                    <label>Venha fazer parte de nossa rede voltada para o design!<br>
                        Aqui você poderá armazenar seus trabalhos, e até mesmo deixá-los públicos
                        para que outras pessoas vejam.<br>
                        Quem sabe alguém não se interesse e lhe faça uma proposta por algum trabalho seu, né?<label>
                </div><br>
                    <?php if(auth()->guard()->check()): ?>
                        <a href="<?php echo e(url('/home')); ?>"><button>HOME</button></a>
                    <?php else: ?>
                        <a href="<?php echo e(route('login')); ?>"><button>LOGIN</button></a>

                        <?php if(Route::has('register')): ?>
                            <a href="<?php echo e(route('register')); ?>"><button>REGISTRAR</button></a>
                        <?php endif; ?>
                    <?php endif; ?>
            </div>
        </div>
        </div>
    </body>
</html>
<?php /**PATH C:\xampp\htdocs\projetoPortifolio\resources\views/welcome.blade.php ENDPATH**/ ?>