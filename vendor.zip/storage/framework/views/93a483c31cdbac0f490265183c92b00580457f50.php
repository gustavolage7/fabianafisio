<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Faby Nephelle - Saúde e Beleza</title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet">

        <!-- Styles -->

<style>

#h1{
    font-size: 30px;
    font-weight: bold;
    margin-bottom: 30px;
    text-align: center;
}

#mae{
    height: 320px;
    margin-top: 10%;
    margin-left: 10%;
    width: 350px;
    background-image: url("img/fundoform.png");

}

#campo{
    width: 300px;
    height: 25px;
    text-align: center;
    margin-left: 5%;

}

#remember{
    text-align: center;
    margin-left: 5%;
}

#creditos_bg{
    margin-top: 10%;
}

button{
    background-color: #FFC0CB;
    width: 150px;
    height: 40px;
    margin-left: 4%;
}

button:hover{
    background-color: #C71585;
    color: white;
}

html{
    background-image: url("img/BG Welcome.jpg");
    background-repeat: no-repeat, repeat;
    background-size: 100% 100%;
    background-position: center;
    height: 100%;
}

</style>
</head>
<body>
<div class="container" id="mae">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <br>
                <div class="card-header" id='h1'>Login</div>

                <div class="card-body" id="form">
                    <form method="POST" action="<?php echo e(route('login')); ?>">
                        <?php echo csrf_field(); ?>

                        <div class="form-group row">
                            
                            <div class="col-md-6">
                                <input placeholder="E-mail" id="campo" type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email" autofocus>

                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <br>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <br>
                        <div class="form-group row">
                            
                            <div class="col-md-6">
                                <input placeholder="Senha" id="campo" type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password" required autocomplete="current-password">

                                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <br>
                        <div class="form-group row">
                            <div class="col-md-6 offset-md-4">
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" name="remember" id="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>>

                                    <label class="form-check-label" for="remember">
                                        Mantenha-me conectado
                                    </label>
                                </div>
                            </div>
                        </div>
                        <br>
                        <div>
                            <div>
                                <button type="submit">
                                    Login
                                </button>
                                <a href="/">
                                <button type="button">
                                Voltar
                                </button>
                                </a>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<div id="creditos_bg">
    <a href="https://br.freepik.com/fotos/fundo">Fundo foto criado por valeria_aksakova - br.freepik.com</a>
</div>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\painel_revenda\resources\views/auth/login.blade.php ENDPATH**/ ?>