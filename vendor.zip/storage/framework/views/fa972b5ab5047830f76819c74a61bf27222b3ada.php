<!DOCTYPE html>
<html lang="pt-br">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        
        <!-- SEO Meta Tags -->
        <meta name="description" content="Your description">
        <meta name="author" content="Your name">

        <!-- OG Meta Tags to improve the way the post looks when you share the page on Facebook, Twitter, LinkedIn -->
        <meta property="og:site_name" content="" /> <!-- website name -->
        <meta property="og:site" content="" /> <!-- website link -->
        <meta property="og:title" content=""/> <!-- title shown in the actual shared post -->
        <meta property="og:description" content="" /> <!-- description shown in the actual shared post -->
        <meta property="og:image" content="" /> <!-- image link, make sure its jpg -->
        <meta property="og:url" content="" /> <!-- where do you want your post to link to -->
        <meta name="twitter:card" content="summary_large_image"> <!-- to have large image post format in Twitter -->

        <!-- Webpage Title -->
        
        <!-- Styles -->
        <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@700&family=Open+Sans:ital,wght@0,400;0,700;1,400&display=swap" rel="stylesheet">
		<!-- Favicon -->
  <link rel="shortcut icon" href="<?php echo e(asset('dist/img/favicon/favicon.png')); ?>" />
  <!-- Google Font: Source Sans Pro -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="<?php echo e(asset('plugins/fontawesome-free/css/all.min.css')); ?>">
  <!-- Ionicons -->
  <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
  <!-- Tempusdominus Bootstrap 4 -->
  <link rel="stylesheet" href="<?php echo e(asset('plugins/tempusdominus-bootstrap-4/css/tempusdominus-bootstrap-4.min.css')); ?>">
  <!-- iCheck -->
  <link rel="stylesheet" href="<?php echo e(asset('plugins/icheck-bootstrap/icheck-bootstrap.min.css')); ?>">
  <!-- JQVMap -->
  <link rel="stylesheet" href="<?php echo e(asset('plugins/jqvmap/jqvmap.min.css')); ?>">
  <!-- Theme style -->
  <link rel="stylesheet" href="<?php echo e(asset('dist/css/crm.css')); ?>">
  <!-- overlayScrollbars -->
  <link rel="stylesheet" href="<?php echo e(asset('plugins/overlayScrollbars/css/OverlayScrollbars.min.css')); ?>">
  <!-- Daterange picker -->
  <link rel="stylesheet" href="<?php echo e(asset('plugins/daterangepicker/daterangepicker.css')); ?>">
  <!-- summernote -->
  <link rel="stylesheet" href="<?php echo e(asset('plugins/summernote/summernote-bs4.min.css')); ?>">
  <!-- Datatables -->
  <link rel="stylesheet" href="<?php echo e(asset('plugins/datatables-bs4/css/dataTables.bootstrap4.min.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('plugins/datatables-buttons/css/buttons.dataTables.min.1.5.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('plugins/sweetalert2-theme-bootstrap-4/bootstrap-4.min.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('plugins/toastr/toastr.min.css')); ?>">
  <link href="https://gitcdn.github.io/bootstrap-toggle/2.2.2/css/bootstrap-toggle.min.css" rel="stylesheet">
  <link rel="stylesheet" href="<?php echo e(asset('dist/js/plugins/intl-tel-input/build/css/intlTelInput.css')); ?>">
  <!-- fullCalendar -->
  <link rel="stylesheet" href="<?php echo e(asset('plugins/fullcalendar/main.css')); ?>">
        <link href="<?php echo e(asset('css/bootstrap.min.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('css/fontawesome-all.min.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('css/swiper.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('css/styles.css')); ?>" rel="stylesheet">
        
        <!-- Favicon  -->
        <link rel="icon" href="<?php echo e(asset('img/favicon.png')); ?>">
        <title>Dra. Fabiana - Fisioterapia</title>
    </head>
    <body data-bs-spy="scroll" data-bs-target="#navbarExample">
        
        <!-- Navigation -->
        <nav id="navbarExample" class="navbar navbar-expand-lg fixed-top navbar-dark" aria-label="Main navigation">
            <div class="container">

                <!-- Image Logo -->
                <a class="navbar-brand logo-image" href="index.html"><img src="<?php echo e(asset('img/logo.png')); ?>" alt="alternative"></a> 

                <button class="navbar-toggler p-0 border-0" type="button" id="navbarSideCollapse" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="navbar-collapse offcanvas-collapse" id="navbarsExampleDefault">
                    <ul class="navbar-nav ms-auto navbar-nav-scroll">
                        <li class="nav-item">
                            <a class="nav-link" href="#header">Home</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#sobre">Sobre</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#servicos">Serviços</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#projects" hidden>Equipe</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#about" hidden>About</a>
                        </li>
                        <li class="nav-item dropdown" hidden>
                            <a class="nav-link dropdown-toggle" href="#" id="dropdown01" data-bs-toggle="dropdown" aria-expanded="false">Drop</a>
                            <ul class="dropdown-menu" aria-labelledby="dropdown01">
                                <li><a class="dropdown-item" href="article.html">Article Details</a></li>
                                <li><div class="dropdown-divider"></div></li>
                                <li><a class="dropdown-item" href="terms.html">Terms Conditions</a></li>
                                <li><div class="dropdown-divider"></div></li>
                                <li><a class="dropdown-item" href="privacy.html">Privacy Policy</a></li>
                            </ul>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#contact">Contact</a>
                        </li>
                    </ul>
                    <span class="nav-item social-icons">
                        <span class="fa-stack">
                            <a href="#your-link">
                                <i class="fas fa-circle fa-stack-2x"></i>
                                <i class="fab fa-facebook-f fa-stack-1x"></i>
                            </a>
                        </span>
                        <span class="fa-stack">
                            <a href="#your-link">
                                <i class="fas fa-circle fa-stack-2x"></i>
                                <i class="fab fa-twitter fa-stack-1x"></i>
                            </a>
                        </span>
                    </span>
                </div> <!-- end of navbar-collapse -->
            </div> <!-- end of container -->
        </nav> <!-- end of navbar -->
        <!-- end of navigation -->

        
        <!-- Header -->
        <header id="header" class="header">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="text-container">
                            <h1 class="h1-large">Drª Fabiana, <span class="replace-me">Fisioterapeuta, Professora Particular, Instrutora de Pilates</span></h1>
                            <p class="p-large" style="width: 100%;">Formada pela Faculdade Ciências Médicas de Minas Gerais e preparada para lhe atender</p>
                            <a class="btn-solid-lg" href="#sobre">Saiba mais</a>
                        </div> <!-- end of text-container -->
                    </div> <!-- end of col -->
                </div> <!-- end of row -->
            </div> <!-- end of container -->
        </header> <!-- end of header -->
        <!-- end of header -->


        <!-- Sobre -->
        <div id="sobre" class="basic-1">
            <div class="container">
                <div class="row">
                    <div class="col-lg-5">
                        <div class="text-container">
                            <div class="section-title">Sobre</div>
                            <h2>
								Fabiana Carvalho Gonçalves
								<br>
								Belo Horizonte - MG
							</h2>
                            <h2></h2>
                            <p>Fisioterapeuta formada em 2021 pela Faculdade Ciências Médicas de Minas Gerais, atuo nos segmentos de fisioterapia em idosos, ortopédica, neurológica e uroginecológica.</p>
                            <p>Além de fisioterapeuta, possuo os cursos de cuidadora de idosos e de instrutora para pilates modalidade solo e treinamento funcional.</p>
                            <p>Trabahando sempre para o melhor atendimento, com qualidade e satisfação de meus pacientes.</p>
                        </div> <!-- end of text-container -->
                    </div> <!-- end of col -->
                    <div class="col-lg-7">
                        <div class="image-container">
                            <img class="img-fluid" src="<?php echo e(asset('img/intro-office.jpg')); ?>" alt="alternative">
                        </div> <!-- end of image-container -->
                    </div> <!-- end of col -->
                </div> <!-- end of row -->
            </div> <!-- end of container -->
        </div> <!-- end of basic-1 -->
        <!-- end of sobre -->


        <!-- Serviços -->
        <div id="servicos" class="cards-2 bg-gray">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="section-title">Serviços</div>
                        <h2 class="h2-heading">Serviços prestados</h2>
                    </div> <!-- end of col -->
                </div> <!-- end of row -->
                <div class="row">
                    <div class="col-lg-12">
                        
                        <!-- Card -->
                        <div class="card">
                            <div class="card-image">
                                <img class="img-fluid" src="<?php echo e(asset('img/service-1.jpg')); ?>" alt="alternative">
                            </div>
                            <div class="card-body">
                                <h4 class="card-title">Fisioterapia</h4>
                                <p>Tratamentos oferecidos na área em atendimento domiciliar</p>
                                <ul class="list-unstyled li-space-lg">
                                    <li class="d-flex">
                                        <i class="fas fa-square"></i>
                                        <div class="flex-grow-1">Neurológica do Adulto</div>
                                    </li>
                                    <li class="d-flex">
                                        <i class="fas fa-square"></i>
                                        <div class="flex-grow-1">Urológica</div>
                                    </li>
                                    <li class="d-flex">
                                        <i class="fas fa-square"></i>
                                        <div class="flex-grow-1">Traumato-Ortopédica</div>
                                    </li>
                                    <li class="d-flex">
                                        <i class="fas fa-square"></i>
                                        <div class="flex-grow-1">Gerontológica</div>
                                    </li>
                                </ul>
                                <div class="price">Cada sessão dura 1 hora</span></div>
                                <div class="price">Sessão avulsa <span>R$90,00/hora</span></div>
                                <div class="price">Pacote 10 sessões <span>R$800,00</span></div>
                                <div class="price">Pacote 20 sessões <span>R$1.500,00</span></div>
                            </div>
                        </div>
                        <!-- end of card -->

                        <!-- Card -->
                        <div class="card">
                            <div class="card-image">
                                <img class="img-fluid" src="<?php echo e(asset('img/service-2.jpg')); ?>" alt="alternative">
                            </div>
                            <div class="card-body">
                                <h4 class="card-title">Pilates/Treino Funcional</h4>
                                <p>Exercícios com acessórios funcionais e sem utilização de aparelhos.</p>
                                <ul class="list-unstyled li-space-lg">
                                    <li class="d-flex">
                                        <i class="fas fa-square"></i>
                                        <div class="flex-grow-1">Pilates Solo</div>
                                    </li>
                                    <li class="d-flex">
                                        <i class="fas fa-square"></i>
                                        <div class="flex-grow-1">Treinamento Funcional</div>
                                    </li>
                                </ul>
                                <div class="price">Hora avulsa <span>R$100,00</span></div>
                                <div class="price">10 horas <span>R$900,00</span></div>
                                <div class="price">20 horas <span>R$1.700,00</span></div>
                            </div>
                        </div>
                        <!-- end of card -->

                        <!-- Card -->
                        <div class="card">
                            <div class="card-image">
                                <img class="img-fluid" src="<?php echo e(asset('img/biologia.png')); ?>" alt="alternative">
                            </div>
                            <div class="card-body">
                                <h4 class="card-title">Professora Particular</h4>
                                <div>&nbsp</div>
                                <p>Aula particular e acompanhamento escolar constante na matéria</p>
                                <div>&nbsp</div>
                                <ul class="list-unstyled li-space-lg">
                                    <li class="d-flex">
                                        <i class="fas fa-square"></i>
                                        <div class="flex-grow-1">Biologia</div>
                                    </li>
                                </ul>
                                <div>&nbsp</div>
                                <div class="price">Por hora: <span>R$ 60,00</span></div>
                            </div>
                        </div>
                        <!-- end of card -->

                    </div> <!-- end of col -->
                </div> <!-- end of row -->
				<div class="row">
					<div class="col-md-12 txt_maisinfo">
						Para maiores informações me chame no Whatsapp <a href="https://web.whatsapp.com/send?phone=5531996801287" target="_blank">clicando aqui <img class="icon" src="<?php echo e(asset('img/wpicon.png')); ?>" alt="alternative"></a>
					</div>
				</div>
            </div> <!-- end of container -->
        </div> <!-- end of cards-2 -->
        <!-- end of servicos -->


        <!-- Projects Modals -->
        <div class="projects-modals" id="projects" hidden>

            <!-- Team -->
            <div class="card-2 bg-gray">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-12">
                            <h2 class="h2-heading">Nossa equipe</h2>
                            <p class="p-heading">Mauris facilisis urna urna, non volutpat tortor rhoncus nec. Vivamus consectetur dui quis libero tempus, ut eleifend ex consectetur nulla vel que vivo rempa</p>
                        </div> <!-- end of col -->
                    </div> <!-- end of row -->
                    <div class="row">
                        <div class="col-lg-12">

                            <!-- Card -->
                            <div class="card">
                                <div class="card-image">
                                    <img class="img-fluid" src="<?php echo e(asset('img/team-member-1.jpg')); ?>" alt="alternative">
                                </div>
                                <div class="card-body">
                                    <h6 class="card-title">Lacy Whitelong</h6>
                                    <p>Business Developer</p>
                                    <span class="fa-stack">
                                        <a href="#your-link">
                                            <i class="fas fa-circle fa-stack-2x"></i>
                                            <i class="fab fa-twitter fa-stack-1x"></i>
                                        </a>
                                    </span>
                                    <span class="fa-stack">
                                        <a href="#your-link">
                                            <i class="fas fa-circle fa-stack-2x"></i>
                                            <i class="fab fa-linkedin-in fa-stack-1x"></i>
                                        </a>
                                    </span>
                                </div>
                            </div>
                            <!-- end of card -->

                            <!-- Card -->
                            <div class="card">
                                <div class="card-image">
                                    <img class="img-fluid" src="<?php echo e(asset('img/team-member-2.jpg')); ?>" alt="alternative">
                                </div>
                                <div class="card-body">
                                    <h6 class="card-title">Sheila Zimern</h6>
                                    <p>Software Engineer</p>
                                    <span class="fa-stack">
                                        <a href="#your-link">
                                            <i class="fas fa-circle fa-stack-2x"></i>
                                            <i class="fab fa-twitter fa-stack-1x"></i>
                                        </a>
                                    </span>
                                    <span class="fa-stack">
                                        <a href="#your-link">
                                            <i class="fas fa-circle fa-stack-2x"></i>
                                            <i class="fab fa-linkedin-in fa-stack-1x"></i>
                                        </a>
                                    </span>
                                </div>
                            </div>
                            <!-- end of card -->

                            <!-- Card -->
                            <div class="card">
                                <div class="card-image">
                                    <img class="img-fluid" src="<?php echo e(asset('img/team-member-3.jpg')); ?>" alt="alternative">
                                </div>
                                <div class="card-body">
                                    <h6 class="card-title">Chris Brown</h6>
                                    <p>Online Marketer</p>
                                    <span class="fa-stack">
                                        <a href="#your-link">
                                            <i class="fas fa-circle fa-stack-2x"></i>
                                            <i class="fab fa-twitter fa-stack-1x"></i>
                                        </a>
                                    </span>
                                    <span class="fa-stack">
                                        <a href="#your-link">
                                            <i class="fas fa-circle fa-stack-2x"></i>
                                            <i class="fab fa-linkedin-in fa-stack-1x"></i>
                                        </a>
                                    </span>
                                </div>
                            </div>
                            <!-- end of card -->

                            <!-- Card -->
                            <div class="card">
                                <div class="card-image">
                                    <img class="img-fluid" src="<?php echo e(asset('img/team-member-4.jpg')); ?>" alt="alternative">
                                </div>
                                <div class="card-body">
                                    <h6 class="card-title">Mary Villalonga</h6>
                                    <p>Product Manager</p>
                                    <span class="fa-stack">
                                        <a href="#your-link">
                                            <i class="fas fa-circle fa-stack-2x"></i>
                                            <i class="fab fa-twitter fa-stack-1x"></i>
                                        </a>
                                    </span>
                                    <span class="fa-stack">
                                        <a href="#your-link">
                                            <i class="fas fa-circle fa-stack-2x"></i>
                                            <i class="fab fa-linkedin-in fa-stack-1x"></i>
                                        </a>
                                    </span>
                                </div>
                            </div>
                            <!-- end of card -->

                        </div> <!-- end of col -->
                    </div> <!-- end of row -->
                </div> <!-- end of container -->
            </div> <!-- end of card-2 -->
            <!-- end of team -->

        </div>

        <!-- Footer -->
        <div class="footer" id="contact">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="footer-col first">
                            <h6>Sobre o site</h6>
                            <p class="p-small">Site feito e mantido por Gustavo Nephelle, para divulgação dos serviços oferecidos pela Fabiana.</p>
                        </div> <!-- end of footer-col -->
                        <div class="footer-col second">
                            <h6>Contato do desenvolvedor</h6>
                            <p class="p-small">Para informações a respeito do site entrar em contato com Gustavo - gustavonephelle@gmail.com.</p>
                        </div> <!-- end of footer-col -->
                        <div class="footer-col third">
                            <span class="fa-stack">
                                <a href="#your-link">
                                    <i class="fab fa-facebook-f fa-stack-1x"></i>
                                </a>
                            </span>
                            <span class="fa-stack">
                                <a href="#your-link">
                                    <i class="fab fa-twitter fa-stack-1x"></i>
                                </a>
                            </span>
                            <span class="fa-stack">
                                <a href="#your-link">
                                    <i class="fab fa-pinterest-p fa-stack-1x"></i>
                                </a>
                            </span>
                            <span class="fa-stack">
                                <a href="#your-link">
                                    <i class="fab fa-instagram fa-stack-1x"></i>
                                </a>
                            </span>
                            <p class="p-small">Aliquam ultrices turpis rave loro <a href="mailto:contact@site.com"><strong>contact@site.com</strong></a></p>
                        </div> <!-- end of footer-col -->
                    </div> <!-- end of col -->
                </div> <!-- end of row -->
            </div> <!-- end of container -->
        </div> <!-- end of footer -->  
        <!-- end of footer -->


        <!-- Copyright -->
        <div class="copyright">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <p class="p-small">Copyright © Gustavo Nephelle</p>
                    </div> <!-- end of col -->
                </div> <!-- enf of row -->
            </div> <!-- end of container -->
        </div> <!-- end of copyright --> 
        <!-- end of copyright -->
        

        <!-- Back To Top Button -->
        <button onclick="topFunction()" id="myBtn">
            <img src="<?php echo e(asset('img/up-arrow.png')); ?>" alt="alternative">
        </button>
        <!-- end of back to top button -->
            
        <!-- Scripts -->
        <script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script> <!-- Bootstrap framework -->
        <script src="<?php echo e(asset('js/swiper.min.js')); ?>"></script> <!-- Swiper for image and text sliders -->
        <script src="<?php echo e(asset('js/purecounter.min.js')); ?>"></script> <!-- Purecounter counter for statistics numbers -->
        <script src="<?php echo e(asset('js/replaceme.min.js')); ?>"></script> <!-- ReplaceMe for rotating text -->
        <script src="<?php echo e(asset('js/isotope.pkgd.min.js')); ?>"></script> <!-- Isotope for filter -->
        <script src="<?php echo e(asset('js/scripts.js')); ?>"></script> <!-- Custom scripts -->
    </body>
</html><?php /**PATH C:\xampp\htdocs\SiteFafa\resources\views/welcome.blade.php ENDPATH**/ ?>