<?php $__env->startSection('content'); ?>

<style>


        #conteudo{
            background-color: #FFC0CB;
            float: right;
            width: 75%;
            height: 100vh;
        }

        #lateral{
            width: 25%;
            height: 100vh;
            float: left;
        }

        #msg{
            width: 40%;
            height: 30vh;
        }
    
        h1{
            text-align: center;
            text-decoration-line: underline;
            font-weight: bold;
            margin-top: 5%;
        }
    
        h2{
            text-align: center;
        }
    
        img{
            float: right;
            margin-right: 2%;
            width: 400px;
        }

        label{
            font-weight: bold;
            font-size: 20px;
            margin-right: 5%;
        }

        table{
            width: 50%;
        }

        button{
            background-color: #FFC0CB;
            width: 100px;
            height: 40px;
            margin-left: 3%;
            margin-top: 3%;
        }

        button:hover{
            background-color: #C71585;
            color: white;
        }

</style>

<div class="container" >
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">

                <div class="card-body" id='mae'>
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    
                    <div id='conteudo'>
                        <h1>Novo Contato</h1>
                        <div id="lateral">
                            
                        </div>
                        <form method="POST" action="/contatos/criarContato">
                            <?php echo csrf_field(); ?>
    
                            <div class="form-group row">
                                
                                <div class="col-md-6">
                                    <label>Título: </label><br>
                                    <input minlength="5" maxlength="100" onkeypress="return onlyletter();" placeholder="Título(Até 100 caracteres)" id="titulo" type="text" name="titulo" required autocomplete="titulo" autofocus>
    
                                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <br>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <br>
                            <div class="form-group row">
                                
                                <div class="col-md-6">
                                    <label>Mensagem: </label><br>
                                    <textarea placeholder="Mensagem (Máx 5000 caracteres)" id="msg" type="textarea" name="msg" required autocomplete="msg"></textarea>
    
                                </div>
                            </div>
                            <input id="id_user" name="id_user" value="<?php echo e(auth()->user()->id); ?>" hidden>
                            <br>
                            
                                <button type="submit">
                                            Salvar
                                </button>
                                <a href="/contatos">
                                <button type="button">
                                    Voltar
                                </button>
                                </a>
                        </form>
                        
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\painel_revenda\resources\views/cadastrarContato.blade.php ENDPATH**/ ?>