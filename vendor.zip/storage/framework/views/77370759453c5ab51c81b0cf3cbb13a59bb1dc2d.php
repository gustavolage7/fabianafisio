<?php $__env->startSection('content'); ?>

<style>


        #conteudo{
            background-color: #FFC0CB;
            float: right;
            width: 75%;
            height: 100vh;
        }

        #lateral{
            width: 25%;
            height: 100vh;
            float: left;
        }

        #colA{
            width: 40%;
        }

        #colB{
            width: 60%;
        }

        #TR_Impar{
            background-color: #B0C4DE;
        }

        #TR_Par{
            background-color: #ffecef;
        }
    
        h1{
            text-align: center;
            text-decoration-line: underline;
            font-weight: bold;
            margin-top: 5%;
        }
    
        h2{
            text-align: center;
        }
    
        img{
            float: right;
            margin-right: 2%;
            width: 400px;
        }

        label{
            font-weight: bold;
            font-size: 20px;
            margin-right: 5%;
        }

        table{
            width: 50%;
        }

        button{
            background-color: #FFC0CB;
            width: 100px;
            height: 40px;
            margin-left: 20%;
            margin-top: 5%;
        }

        button:hover{
            background-color: #C71585;
            color: white;
        }

</style>

<div class="container" >
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">

                <div class="card-body" id='mae'>
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    
                    <div id='conteudo'>
                        <h1>Perfil</h1>
                        <div id="lateral">
                            
                        </div>
                        
                        <table>

                        <tr id="TR_Impar">
                        <td id="colA"><label>Nome:</label></td>
                        <td id="colB"><?php echo e(Auth::user()->name); ?></td>
                        </tr>
                        <tr id="TR_Par">
                        <td id="colA"><label>E-mail:</label></td>
                        <td id="colB"><?php echo e(Auth::user()->email); ?></td>
                        </tr>
                        <tr id="TR_Impar">
                        <td id="colA"><label>Usuário:</label></td>
                        <td id="colB"><?php echo e(Auth::user()->usuario); ?><td>
                        </tr>
                        <tr id="TR_Par">
                        <td id="colA"><label>Telefone:</label></td>
                        <td id="colB"><?php echo e(Auth::user()->telefone); ?></td>
                        </tr>
                        <tr id="TR_Impar">
                        <td id="colA"><label>CPF:</label></td>
                        <td id="colB"><?php echo e(Auth::user()->cpf); ?></td>
                        </tr>
                        <tr id="TR_Par">
                        <td id="colA"><label>Acesso:</label></td>
                        <td id="colB"><?php echo e(Auth::user()->acesso); ?></td>
                        </tr>
                        <tr id="TR_Impar">
                        <td id="colA"><label>Data de Nascimento:</label></td>
                        <td id="colB"><?php echo e(date('d/m/Y', strtotime(Auth::user()->nascimento))); ?></td>
                        </tr>
                         </table>
                         <?php $id = Auth::user()->id; ?>
                        <a href="/usuarios/editarPerfil/<?php echo e($id); ?>">
                            <button type="button">
                                Editar
                            </button>
                        </a>
                        
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\painel_revenda\resources\views/perfil.blade.php ENDPATH**/ ?>